/**
 * Vercel Serverless Function: /api/solve
 * Secure backend proxy for Google Gemini API.
 * Keeps GEMINI_API_KEY completely hidden from the browser.
 */

// In-memory rate limiting map for basic protection on serverless instances
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 20;

function checkRateLimit(ip) {
  const now = Date.now();
  const clientData = rateLimitMap.get(ip) || { count: 0, resetTime: now + RATE_LIMIT_WINDOW_MS };

  if (now > clientData.resetTime) {
    clientData.count = 1;
    clientData.resetTime = now + RATE_LIMIT_WINDOW_MS;
    rateLimitMap.set(ip, clientData);
    return true;
  }

  if (clientData.count >= MAX_REQUESTS_PER_WINDOW) {
    return false;
  }

  clientData.count++;
  rateLimitMap.set(ip, clientData);
  return true;
}

// Sanitization utility
function sanitizeInput(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/[<>]/g, '') // remove HTML tags
    .trim()
    .slice(0, 1000); // limit payload length
}

export default async function handler(req, res) {
  // 1. CORS Headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed. Use POST.' });
  }

  // 2. Rate Limiting based on IP
  const clientIp = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown-ip';
  if (!checkRateLimit(clientIp)) {
    return res.status(429).json({
      error: 'Too many requests. Please wait a minute before solving another entry.',
    });
  }

  // 3. Parse and sanitize input
  const { transaction } = req.body || {};
  const cleanedText = sanitizeInput(transaction);

  if (!cleanedText) {
    return res.status(400).json({ error: 'Please provide a valid accounting transaction text.' });
  }

  // 4. Retrieve Gemini API Key from environment
  const apiKey = process.env.GEMINI_API_KEY;

  // If no Gemini API key configured, use built-in deterministic accounting solver
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    console.warn('GEMINI_API_KEY is not set. Using built-in rule solver.');
    const ruleResult = solveWithRules(cleanedText);
    return res.status(200).json(ruleResult);
  }

  // 5. Call Gemini API securely via server-side fetch
  try {
    const geminiEndpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;

    const systemPrompt = `You are an expert Chartered Accountant and Tally Prime specialist.
Analyze this accounting transaction and return a strict JSON object with exact Tally Double Entry details:
{
  "voucherType": "Receipt" | "Payment" | "Contra" | "Sales" | "Purchase" | "Journal" | "Credit Note" | "Debit Note",
  "voucherShortcut": "F6" | "F5" | "F4" | "F8" | "F9" | "F7" | "Alt+F6" | "Alt+F5",
  "voucherExplanation": "Concise explanation of voucher choice in Tally",
  "debitLedger": "Debit Ledger Name",
  "debitAmount": "1,00,000",
  "debitGroup": "Tally Group (e.g. Cash-in-hand, Indirect Expenses, Sundry Debtors)",
  "debitRule": "Real Account / Personal Account / Nominal Account with rule reason",
  "creditLedger": "Credit Ledger Name",
  "creditAmount": "1,00,000",
  "creditGroup": "Tally Group (e.g. Capital Account, Sales Accounts, Sundry Creditors)",
  "creditRule": "Real Account / Personal Account / Nominal Account with rule reason",
  "narration": "(Being ...)",
  "goldenRulesSummary": "Summary of Golden Rules applied",
  "tallySteps": ["Step 1", "Step 2", "Step 3", "Step 4"]
}`;

    const response = await fetch(geminiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: systemPrompt + '\n\nTransaction: ' + cleanedText },
            ],
          },
        ],
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0.1,
        },
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      console.error('Gemini API call returned non-200:', response.status, errBody);
      // Seamlessly fallback to rule solver instead of breaking client experience
      const fallbackResult = solveWithRules(cleanedText);
      return res.status(200).json(fallbackResult);
    }

    const data = await response.json();
    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    const parsed = JSON.parse(rawText || '{}');

    return res.status(200).json({
      ...parsed,
      source: 'gemini-ai',
    });
  } catch (error) {
    console.error('Backend error calling Gemini API:', error);
    // Return high quality heuristic fallback result
    const fallbackResult = solveWithRules(cleanedText);
    return res.status(200).json(fallbackResult);
  }
}

// Built-in rule engine for instant zero-failure responses
function solveWithRules(text) {
  const lower = text.toLowerCase();
  const amountMatch = text.match(/(?:rs\.?|inr|₹)?\s*([0-9]{1,3}(?:,[0-9]{2,3})*(?:\.[0-9]{1,2})?|[0-9]+)/i);
  const amount = amountMatch ? amountMatch[1] : '1,00,000';

  if (lower.includes('started business') || lower.includes('commenced business') || lower.includes('capital')) {
    const isBank = lower.includes('bank') || lower.includes('cheque');
    return {
      voucherType: 'Receipt',
      voucherShortcut: 'F6',
      voucherExplanation: 'Funds received into business from the proprietor as capital contribution.',
      debitLedger: isBank ? 'Bank Account' : 'Cash Account',
      debitAmount: amount,
      debitGroup: isBank ? 'Bank Accounts' : 'Cash-in-hand',
      debitRule: 'Real Account: Debit what comes in (Cash/Bank balance increases)',
      creditLedger: 'Capital Account',
      creditAmount: amount,
      creditGroup: 'Capital Account',
      creditRule: 'Personal Account: Credit the giver (Proprietor)',
      narration: '(Being capital introduced by proprietor to commence business)',
      goldenRulesSummary: 'Cash is Real A/c (Debit what comes in). Capital is Personal A/c (Credit the giver).',
      tallySteps: [
        'Open Gateway of Tally > Vouchers.',
        'Press [F6] for Receipt Voucher.',
        'In Account: Select Cash or Bank Account.',
        'In Particulars: Select Capital Account, enter amount.',
        'Press Ctrl+A to save.',
      ],
      source: 'rule-engine',
    };
  }

  if (lower.includes('deposited') && (lower.includes('bank') || lower.includes('cash'))) {
    return {
      voucherType: 'Contra',
      voucherShortcut: 'F4',
      voucherExplanation: 'Internal cash transfer between cash drawer and bank account.',
      debitLedger: 'Bank Account',
      debitAmount: amount,
      debitGroup: 'Bank Accounts',
      debitRule: 'Personal / Real Account: Debit the receiver (Bank balance rises)',
      creditLedger: 'Cash Account',
      creditAmount: amount,
      creditGroup: 'Cash-in-hand',
      creditRule: 'Real Account: Credit what goes out (Physical cash leaves)',
      narration: '(Being cash deposited into bank)',
      goldenRulesSummary: 'Bank receives deposit (Debit). Cash departs (Credit). Recorded in Contra [F4].',
      tallySteps: [
        'Open Gateway of Tally > Vouchers.',
        'Press [F4] for Contra Voucher.',
        'Select Bank in Account, Cash in Particulars.',
        'Press Ctrl+A to save.',
      ],
      source: 'rule-engine',
    };
  }

  if (lower.includes('purchased goods') || lower.includes('bought goods')) {
    const isCredit = lower.includes('credit') || (!lower.includes('cash') && !lower.includes('bank') && lower.includes('from'));
    const party = text.match(/from\s+([A-Za-z0-9\s.,]+?)(?:\s+on|\s+for|\s+rs|$)/i)?.[1]?.trim() || 'Sundry Creditor';

    if (isCredit) {
      return {
        voucherType: 'Purchase',
        voucherShortcut: 'F9',
        voucherExplanation: 'Credit purchase of resale inventory items from vendor.',
        debitLedger: 'Purchases Account',
        debitAmount: amount,
        debitGroup: 'Purchase Accounts',
        debitRule: 'Nominal Account: Debit all expenses and losses',
        creditLedger: `${party} (Creditor)`,
        creditAmount: amount,
        creditGroup: 'Sundry Creditors',
        creditRule: 'Personal Account: Credit the giver (Vendor)',
        narration: `(Being goods purchased on credit from ${party})`,
        goldenRulesSummary: 'Purchases is Nominal (Debit expenses). Supplier is Personal (Credit the giver).',
        tallySteps: [
          'Press [F9] for Purchase Voucher.',
          `Party: ${party} A/c (Sundry Creditors).`,
          'Purchase Ledger: Purchases Account.',
          'Press Ctrl+A to save.',
        ],
        source: 'rule-engine',
      };
    } else {
      return {
        voucherType: 'Payment / Purchase',
        voucherShortcut: 'F5 / F9',
        voucherExplanation: 'Cash purchase of trade goods.',
        debitLedger: 'Purchases Account',
        debitAmount: amount,
        debitGroup: 'Purchase Accounts',
        debitRule: 'Nominal Account: Debit all expenses and losses',
        creditLedger: 'Cash Account',
        creditAmount: amount,
        creditGroup: 'Cash-in-hand',
        creditRule: 'Real Account: Credit what goes out',
        narration: '(Being goods purchased for cash)',
        goldenRulesSummary: 'Purchases is Nominal (Debit). Cash is Real (Credit).',
        tallySteps: ['Press [F9] or [F5], enter Cash & Purchases A/c, save.'],
        source: 'rule-engine',
      };
    }
  }

  if (lower.includes('sold goods') || lower.includes('sale of goods')) {
    const isCredit = lower.includes('credit') || (!lower.includes('cash') && !lower.includes('bank') && lower.includes('to'));
    const party = text.match(/to\s+([A-Za-z0-9\s.,]+?)(?:\s+on|\s+for|\s+rs|$)/i)?.[1]?.trim() || 'Sundry Debtor';

    if (isCredit) {
      return {
        voucherType: 'Sales',
        voucherShortcut: 'F8',
        voucherExplanation: 'Credit sale of goods to customer on trade account.',
        debitLedger: `${party} (Debtor)`,
        debitAmount: amount,
        debitGroup: 'Sundry Debtors',
        debitRule: 'Personal Account: Debit the receiver (Customer)',
        creditLedger: 'Sales Account',
        creditAmount: amount,
        creditGroup: 'Sales Accounts',
        creditRule: 'Nominal Account: Credit all incomes and gains',
        narration: `(Being goods sold on credit to ${party})`,
        goldenRulesSummary: 'Debtor is Personal (Debit receiver). Sales is Nominal (Credit revenue).',
        tallySteps: [
          'Press [F8] for Sales Voucher.',
          `Party: ${party} A/c (Sundry Debtors).`,
          'Sales Ledger: Sales Account.',
          'Press Ctrl+A to save.',
        ],
        source: 'rule-engine',
      };
    } else {
      return {
        voucherType: 'Receipt / Sales',
        voucherShortcut: 'F6 / F8',
        voucherExplanation: 'Cash sale of inventory with instant collection.',
        debitLedger: 'Cash Account',
        debitAmount: amount,
        debitGroup: 'Cash-in-hand',
        debitRule: 'Real Account: Debit what comes in',
        creditLedger: 'Sales Account',
        creditAmount: amount,
        creditGroup: 'Sales Accounts',
        creditRule: 'Nominal Account: Credit all incomes and gains',
        narration: '(Being goods sold for cash)',
        goldenRulesSummary: 'Cash is Real (Debit what comes in). Sales is Nominal (Credit income).',
        tallySteps: ['Press [F8] or [F6], select Cash & Sales A/c, save.'],
        source: 'rule-engine',
      };
    }
  }

  if (lower.includes('paid rent') || lower.includes('paid salary') || lower.includes('paid electricity') || lower.includes('paid commission') || lower.includes('paid wages')) {
    const expMatch = text.match(/paid\s+([A-Za-z\s]+?)(?:\s+by|\s+to|\s+of|\s+rs|$)/i);
    const exp = expMatch ? expMatch[1].trim() : 'Expense';
    const isBank = lower.includes('cheque') || lower.includes('bank') || lower.includes('online');

    return {
      voucherType: 'Payment',
      voucherShortcut: 'F5',
      voucherExplanation: 'Disbursement of operating expenditure funds.',
      debitLedger: `${exp.charAt(0).toUpperCase() + exp.slice(1)} Account`,
      debitAmount: amount,
      debitGroup: 'Indirect Expenses',
      debitRule: 'Nominal Account: Debit all expenses and losses',
      creditLedger: isBank ? 'Bank Account' : 'Cash Account',
      creditAmount: amount,
      creditGroup: isBank ? 'Bank Accounts' : 'Cash-in-hand',
      creditRule: 'Real Account: Credit what goes out (Payment made)',
      narration: `(Being ${exp} paid ${isBank ? 'by cheque' : 'in cash'})`,
      goldenRulesSummary: 'Expense is Nominal (Debit). Cash/Bank is Real (Credit what goes out).',
      tallySteps: [
        'Press [F5] for Payment Voucher.',
        `Account: ${isBank ? 'Bank' : 'Cash'}.`,
        `Particulars: ${exp} Account.`,
        'Press Ctrl+A to save.',
      ],
      source: 'rule-engine',
    };
  }

  // Default fallback
  return {
    voucherType: 'Journal',
    voucherShortcut: 'F7',
    voucherExplanation: 'General accounting journal voucher in Tally Prime.',
    debitLedger: 'Debit Ledger Account',
    debitAmount: amount,
    debitGroup: 'Indirect Expenses / Assets',
    debitRule: 'Debit what comes in / Debit expenses / Debit receiver',
    creditLedger: 'Credit Ledger Account',
    creditAmount: amount,
    creditGroup: 'Sundry Creditors / Revenue / Capital',
    creditRule: 'Credit what goes out / Credit revenue / Credit giver',
    narration: `(Being transaction recorded: ${text})`,
    goldenRulesSummary: 'Dual Aspect Principle: Every transaction has equal debit and credit entries.',
    tallySteps: ['Press [F7] for Journal, enter Dr/Cr ledgers, press Ctrl+A.'],
    source: 'rule-engine',
  };
}
